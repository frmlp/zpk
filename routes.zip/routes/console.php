<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;

// w tytm pliku definiujemy dodatkowe komendy artisan
// dla nas nie będzie potrzebny
// chyba można usunąć

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote')->hourly();
